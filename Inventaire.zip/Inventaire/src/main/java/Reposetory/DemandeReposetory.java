package Reposetory;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import Entites.Demande;

public class DemandeReposetory implements IDemandeReposetory{
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("inva");
	private EntityManager entityManger = entityManagerFactory.createEntityManager();
	@Override
	public void addDemande(Demande demande) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			entityManger.persist(demande);
			transaction.commit();
		} catch (Exception e) {
			// TODO: handle exception
			transaction.rollback();
			e.printStackTrace();
		}
	}

	@Override
	public void deleteDemande(Long id) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			Demande demande = entityManger.find(Demande.class, id);
			entityManger.remove(demande);
			transaction.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}

	@Override
	public void updateDemande(Demande demande) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			entityManger.merge(demande);
			transaction.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	@Override
	public List<Demande> getDemandes() {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select d from Demande d");
		return query.getResultList();
	}

	@Override
	public Demande getDemande(Long id) {
		// TODO Auto-generated method stub
		Demande demande = entityManger.find(Demande.class, id);
		return demande;
	}

	@Override
	public List<Demande> getDemandeByEtat() {
		// TODO Auto-generated method stub
		String etatM = "approuver";
		String etatC = "non recois";
		Query query = entityManger.createQuery("select d from Demande d Where d.etatManager =:x and d.etatCollecteur=:y");
		query.setParameter("x",etatM );
		query.setParameter("y",etatC);
		return query.getResultList();
	}

}
