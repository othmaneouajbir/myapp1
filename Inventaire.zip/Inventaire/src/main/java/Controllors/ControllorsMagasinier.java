package Controllors;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entites.Produit;
import Entites.Rayon;
import Reposetory.IProduitReposetory;
import Reposetory.IRayonReposetory;
import Reposetory.ProduitReposetory;
import Reposetory.RayonReposetory;

/**
 * Servlet implementation class ControllorsMagasinier
 */
public class ControllorsMagasinier extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private IProduitReposetory produitReposetory;
    private IRayonReposetory rayonReposetory;  
    /**
     * @see HttpServlet#HttpServlet()
     */
    @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	produitReposetory = new ProduitReposetory();
    	rayonReposetory = new RayonReposetory();
    }
    public ControllorsMagasinier() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getPathInfo();
		if(action!=null) {
			if("/DemandeProd".equalsIgnoreCase(action)) {
				Long id = Long.parseLong(request.getParameter("idp"));
				
				request.setAttribute("produit", produitReposetory.getProduit(id));
				request.getServletContext().getRequestDispatcher("/ajouterQuantite.jsp").forward(request, response);
			}
		}else {
			request.setAttribute("produitt", produitReposetory.getProduits());
			request.getServletContext().getRequestDispatcher("/ListProdMag.jsp").forward(request, response);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action =request.getParameter("action");
		if(action.equals("ajou")) {
			try {
				String nomp = request.getParameter("nomP");
				Double prix = Double.parseDouble(request.getParameter("prix"));
				Long quantite = Long.parseLong(request.getParameter("qt1"));
				Long quantiteA = Long.parseLong(request.getParameter("qt"));
				Long idProd =Long.parseLong(request.getParameter("idProduit"));
				Long idRayon =Long.parseLong(request.getParameter("idRayon"));
				Date Date= new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("date"));
				Rayon rayon = rayonReposetory.getRayon(idRayon);
				if(quantiteA>quantite) {
					String mesg = "la quantiter demander et superieur de celle de nous stock";
					System.out.println(mesg);
					response.sendRedirect("/Inventaire/Magasinier");
				}else {
					Long qntite = quantite - quantiteA;
					if(qntite==0) {
						String etat = "nnDispo";
						Produit produit = new Produit(idProd, nomp, prix, qntite, Date, etat, rayon);
						produitReposetory.updateProduit(produit);
					}else {
						String etat = "Dispo";
						Produit produit = new Produit(idProd, nomp, prix, qntite, Date, etat, rayon);
						produitReposetory.updateProduit(produit);
					}
					double prixT = prix * quantiteA;
					request.setAttribute("qt", quantiteA);
					request.setAttribute("prix", prixT);
					request.setAttribute("nom", nomp);
					request.getServletContext().getRequestDispatcher("/FactureMag.jsp").forward(request, response);
				}
				
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			
		}
	}

}
