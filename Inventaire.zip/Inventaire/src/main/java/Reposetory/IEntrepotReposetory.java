package Reposetory;

import java.util.List;

import Entites.Entrepot;
import Entites.Produit;

public interface IEntrepotReposetory {
	public void addEntrepot(Entrepot entrepot);
	public void deleteEntrepot(Long idEntrepot);
	public void updateEntrepot(Entrepot entrepot);
	public Entrepot getEntrepot(Long idEntrepot);
	public List<Entrepot> getEntropes();
	public List<Entrepot> getEntrepesByCle(String ville);
	
}
