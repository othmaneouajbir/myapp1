package Reposetory;


import java.util.List;


import Entites.Produit;


public interface IProduitReposetory {
	public void addProduit(Produit produit);
	public void deleteProduit(Long idProduit);
	public void updateProduit(Produit produit);
	public Produit getProduit(Long idProduit);
	public List<Produit> getProduits();
	public List<Produit> getproduitByCle(String name, Long id);
	public List<Produit> ListProduitsParRayon(Long id);
	public List<Produit> getproduitByName(String name);
	public Produit getProduitRayon(Long id1, Long id2);
	public void agmuntProduit(Long ref, Long qantite);
	public Produit getProduitbynom(String nom);
	
}
