package Reposetory;

import java.util.List;
import java.util.ArrayList;

import javax.persistence.*;
import javax.transaction.Transactional;

import Entites.Produit;


public class ProduitReposetory implements IProduitReposetory{
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("inva");
	private EntityManager entityManger = entityManagerFactory.createEntityManager();
	//IRayonReposetory rayonReposetory = new RayonReposetory();
	
	@Override
	public void addProduit(Produit produit) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			entityManger.persist(produit);
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			transaction.rollback();
			e.printStackTrace();
		}
	}

	
	@Override
	public List<Produit> getProduits() {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select p from Produit p");
		return query.getResultList();
		
	}

	@Override
	public Produit getProduit(Long idProduit) {
		// TODO Auto-generated method stub
		Produit produit = entityManger.find(Produit.class, idProduit);
		return produit;
	}

	@Override
	public void deleteProduit(Long idProduit) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			Produit produit = entityManger.find(Produit.class, idProduit);
			entityManger.remove(produit);
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void updateProduit(Produit produit) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			entityManger.merge(produit);
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Override
	public List<Produit> getproduitByCle(String name,Long id) {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select p from Produit p JOIN p.rayon r WHERE r.idRayon= :id and p.nameProduit like :x");
		query.setParameter("x", "%"+name+"%");
		query.setParameter("id", id);
		return query.getResultList();
	}


	@Override
	public List<Produit> ListProduitsParRayon(Long id) {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select p from Produit p JOIN p.rayon r WHERE r.idRayon= :id");
		query.setParameter("id", id);
		return query.getResultList();
	}


	@Override
	public List<Produit> getproduitByName(String name) {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select p from Produit p WHERE p.nameProduit like :x");
		query.setParameter("x", "%"+name+"%");
		return query.getResultList();
	}


	@Override
	public Produit getProduitRayon(Long id1, Long id2) {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select p from Produit p JOIN p.rayon r WHERE r.idRayon= :id2 and p.idProduit=:id1");
		query.setParameter("id1", id1);
		query.setParameter("id2", id2);
		Produit produit = (Produit) query.getSingleResult();
		return produit;
	}


	@Override
	@Transactional
	public void agmuntProduit(Long ref, Long qantite) {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("UPDATE Produit p set p.quantity =:x where p.idProduit =:y");
		//Query query = entityManger.createNativeQuery("UPDATE produits  set quantity =:x+quantity where id =:y");
		query.setParameter("x", qantite);
		query.setParameter("y", ref);
		query.executeUpdate();
	}




	@Override
	public Produit getProduitbynom(String nom) {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select p from Produit p WHERE p.nameProduit=:x");
		query.setParameter("x", nom);
		Produit produit = (Produit) query.getSingleResult();
		return produit;
	}

}
