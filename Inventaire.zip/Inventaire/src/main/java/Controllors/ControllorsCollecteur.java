package Controllors;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entites.Demande;
import Entites.Produit;
import Entites.Rayon;
import Reposetory.DemandeReposetory;
import Reposetory.IDemandeReposetory;
import Reposetory.IProduitReposetory;
import Reposetory.IRayonReposetory;
import Reposetory.IRoleReposetory;
import Reposetory.ProduitReposetory;
import Reposetory.RayonReposetory;

/**
 * Servlet implementation class ControllorsCollecteur
 */
public class ControllorsCollecteur extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private IDemandeReposetory demandeReposetory;
    private IProduitReposetory produitReposetory;
    private IRayonReposetory rayonReposetory;
    /**
     * @see HttpServlet#HttpServlet()
     */
    @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	demandeReposetory = new DemandeReposetory();
    	produitReposetory = new ProduitReposetory();
    	rayonReposetory = new RayonReposetory();
    }
    public ControllorsCollecteur() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getPathInfo();
		if(action!=null) {
			if("/editeEtatC".equalsIgnoreCase(action)) {
				Long id = Long.parseLong(request.getParameter("id"));
				String nomp = request.getParameter("nomp");
				Produit produit = produitReposetory.getProduitbynom(nomp);
				Demande demande = demandeReposetory.getDemande(id);
				request.setAttribute("demande", demande);
				request.setAttribute("produit", produit );
				request.getServletContext().getRequestDispatcher("/editeEtatCollecteur.jsp").forward(request, response);
			}
		}else {
			request.setAttribute("demandes", demandeReposetory.getDemandeByEtat());
			request.getServletContext().getRequestDispatcher("/ListDemandeCollecteur.jsp").forward(request, response);
			}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action =request.getParameter("action");
		if(action.equals("EditeEtatC")) {
			try {
				String nomp = request.getParameter("nomp");
				Double prix = Double.parseDouble(request.getParameter("prix"));
				Long quantite = Long.parseLong(request.getParameter("qt"));
				Long idProd =Long.parseLong(request.getParameter("idProduit"));
				Long idRayon =Long.parseLong(request.getParameter("idRayon"));
				Date Date= new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("date"));
				Long idD = Long.parseLong(request.getParameter("idD"));
				Long ref = Long.parseLong(request.getParameter("ref"));
				Long qprod = Long.parseLong(request.getParameter("qprod"));
				String etatC = request.getParameter("etatC");
				String etatM = request.getParameter("etatM");
				Long quantiteN = quantite + qprod;
				Double prixT = prix*qprod;
				Rayon rayon = rayonReposetory.getRayon(idRayon);
				String etat = "Dispo";
				Produit produit = new Produit(idProd, nomp, prix, quantiteN, Date, etat, rayon);
				Demande demande = new Demande(idD, ref, nomp, qprod, etatM, etatC);
				demandeReposetory.updateDemande(demande);
				produitReposetory.updateProduit(produit);
				request.setAttribute("qt", qprod);
				request.setAttribute("prix", prixT);
				request.setAttribute("nom", nomp);
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			request.getServletContext().getRequestDispatcher("/Facture.jsp").forward(request, response);
		}
	}

}
