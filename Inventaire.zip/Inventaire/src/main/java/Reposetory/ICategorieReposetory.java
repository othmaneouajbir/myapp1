package Reposetory;

import java.util.List;

import Entites.Categorie;

public interface ICategorieReposetory {
	public void addCategorie(Categorie categorie);
	public void deleteCategorie(Long id);
	public void updateCategorie(Categorie categorie);
	public Categorie getCategorie(Long id);
	public List<Categorie> getCategories();
	public List<Categorie> getCategoriesByCle(String name);
}
