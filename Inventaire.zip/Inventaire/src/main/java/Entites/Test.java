package Entites;

import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import Reposetory.IRayonReposetory;
import Reposetory.RayonReposetory;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("inva");
		IRayonReposetory ray = new RayonReposetory();
		String e = "jeux";
		List<Rayon> rayons = ray.ListRayonParEntreCat(16L, 1L);
		
		System.out.println(rayons.get(1).getName());
		System.out.println(rayons.get(1).getEntrepot().getName());
		System.out.println(rayons.get(1).getCategorie().getName());
		//System.out.println(rayons.get(1).getName());
	}

}
