package Controllors;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entites.Produit;
import Entites.Rayon;
import Reposetory.IProduitReposetory;
import Reposetory.IRayonReposetory;
import Reposetory.ProduitReposetory;
import Reposetory.RayonReposetory;

/**
 * Servlet implementation class ControllorsProduit
 */
public class ControllorsProduit extends HttpServlet {
	private static final long serialVersionUID = 1L;
     private IProduitReposetory produitReposetory;
     private IRayonReposetory rayonReposetory;
     @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	produitReposetory = new ProduitReposetory();
    	rayonReposetory = new RayonReposetory();
    }
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllorsProduit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setAttribute("rayons", rayonReposetory.getRayons());
		String action = request.getPathInfo();
		if(action!= null) {
			Long id = Long.parseLong(request.getParameter("id"));
			if("/edite".equalsIgnoreCase(action)) {
				Produit produit = produitReposetory.getProduit(id);
				request.setAttribute("produit", produit);
				request.getServletContext().getRequestDispatcher("/Produit.jsp").forward(request, response);
			}else if("/delete".equalsIgnoreCase(action)) {
				produitReposetory.deleteProduit(id);
				response.sendRedirect("/Inventaire/Produit");
			}
		}else {
			request.setAttribute("produits", produitReposetory.getProduits());
			request.getServletContext().getRequestDispatcher("/Produit.jsp").forward(request, response);

			
		}		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action =request.getParameter("action");
		String name = request.getParameter("name");
		Double prix = Double.parseDouble(request.getParameter("prix"));
		Long quantite = Long.parseLong(request.getParameter("quantite"));
		
		
		
		if(action.equals("Save")) {
			try {
				Date Date= new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("date"));
				Long id = Long.parseLong(request.getParameter("rayon"));
				Rayon rayon = rayonReposetory.getRayon(id);

				if(quantite==0) {
					String etat = "nnDispo";
					Produit produit = new Produit(name, prix, quantite, Date, etat, rayon);
					produitReposetory.addProduit(produit);
				}else {
					String etat = "Dispo";
					Produit produit = new Produit(name, prix, quantite, Date, etat, rayon);
					produitReposetory.addProduit(produit);

				}
				
				
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else if(action.equals("Edite")) {
			
			try {
				Long id1 =Long.parseLong(request.getParameter("idProduit"));
				Long id = Long.parseLong(request.getParameter("rayon"));
				Rayon rayon = rayonReposetory.getRayon(id);
				Date Date= new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("date"));
				if(quantite==0) {
					String etat = "nnDispo";
					Produit produit = new Produit(id1, name, prix, quantite, Date, etat, rayon);
					produitReposetory.updateProduit(produit);
				}else {
					String etat = "Dispo";
					Produit produit = new Produit(id1, name, prix, quantite, Date, etat, rayon);
					produitReposetory.updateProduit(produit);
				}
				
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		response.sendRedirect("/Inventaire/Produit");
	}

}
