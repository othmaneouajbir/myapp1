package Reposetory;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import Entites.Entrepot;

public class EntrepotReposetory implements IEntrepotReposetory{
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("inva");
	private EntityManager entityManger = entityManagerFactory.createEntityManager();
	@Override
	public void addEntrepot(Entrepot entrepot) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			entityManger.persist(entrepot);
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			transaction.rollback();
			e.printStackTrace();
		}
	}

	@Override
	public void deleteEntrepot(Long idEntrepot) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			Entrepot entrepot = entityManger.find(Entrepot.class, idEntrepot);
			entityManger.remove(entrepot);
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void updateEntrepot(Entrepot entrepot) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			entityManger.merge(entrepot);
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public Entrepot getEntrepot(Long idEntrepot) {
		// TODO Auto-generated method stub
		Entrepot entrepot = entityManger.find(Entrepot.class, idEntrepot);
		return entrepot;
	}

	@Override
	public List<Entrepot> getEntropes() {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select e from Entrepot e");
		return query.getResultList();
	}

	@Override
	public List<Entrepot> getEntrepesByCle(String ville) {
		Query query = entityManger.createQuery("select e from Entrepot e where e.address like :x");
		query.setParameter("x", "%"+ville+"%");
		return query.getResultList();
	}

	

}
