package Controllors;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entites.Role;
import Entites.Utilisateur;
import Reposetory.IRoleReposetory;
import Reposetory.IUtilisateurReposetory;
import Reposetory.RoleReposetory;
import Reposetory.UtilisateurReposetory;

/**
 * Servlet implementation class ControllorsAdmin
 */
public class ControllorsAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private IUtilisateurReposetory utilisateurReposetory;
    private IRoleReposetory roleReposetory; 
    
    @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	utilisateurReposetory = new UtilisateurReposetory();
    	roleReposetory = new RoleReposetory();
    }
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllorsAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getPathInfo();
		if(action!=null) {
			Long id = Long.parseLong(request.getParameter("id"));
			if("/editeU".equalsIgnoreCase(action)) {
				request.setAttribute("User", utilisateurReposetory.getUser(id));
				request.setAttribute("roles", roleReposetory.getRoles());
				request.getServletContext().getRequestDispatcher("/editeRole.jsp").forward(request, response);
			}
		}else {
			request.setAttribute("Users", utilisateurReposetory.getUsers());
			request.getServletContext().getRequestDispatcher("/User.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action =request.getParameter("action");
		if(action.equals("EditeU")) {
			Long id = Long.parseLong(request.getParameter("idU"));
			String username = request.getParameter("name");
			String password = request.getParameter("pass");
			Long id2 = Long.parseLong(request.getParameter("role"));
			Role role = roleReposetory.getRole(id2);
			Utilisateur utilisateur = new Utilisateur(id, username, password, role);
			utilisateurReposetory.updateUser(utilisateur);
			response.sendRedirect("/Inventaire/Admin");
		}
	}

}
