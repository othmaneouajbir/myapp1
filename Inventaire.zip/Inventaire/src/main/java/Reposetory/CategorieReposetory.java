package Reposetory;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import Entites.Categorie;

public class CategorieReposetory implements ICategorieReposetory{
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("inva");
	private EntityManager entityManger = entityManagerFactory.createEntityManager();
	@Override
	public void addCategorie(Categorie categorie) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			entityManger.persist(categorie);
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			transaction.rollback();
			e.printStackTrace();
		}
	}

	@Override
	public void deleteCategorie(Long id) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			Categorie categorie = entityManger.find(Categorie.class, id);
			entityManger.remove(categorie);
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void updateCategorie(Categorie categorie) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			entityManger.merge(categorie);
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Categorie getCategorie(Long id) {
		// TODO Auto-generated method stub
		Categorie categorie = entityManger.find(Categorie.class, id);
		return categorie;
	}

	@Override
	public List<Categorie> getCategories() {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select c from Categorie c");
		return query.getResultList();
	}

	@Override
	public List<Categorie> getCategoriesByCle(String name) {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select c from Categorie c WHERE c.name like :x");
		query.setParameter("x", "%"+name+"%");
		return query.getResultList();
	}

}
