package Reposetory;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import Entites.Utilisateur;

public class UtilisateurReposetory implements IUtilisateurReposetory{
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("inva");
	private EntityManager entityManger = entityManagerFactory.createEntityManager();
	@Override
	public void addUser(Utilisateur utilisateur) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			entityManger.persist(utilisateur);
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			transaction.rollback();
			e.printStackTrace();
		}
	}

	@Override
	public void updateUser(Utilisateur utilisateur) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			entityManger.merge(utilisateur);
			transaction.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	@Override
	public List<Utilisateur> getUsers() {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select u from Utilisateur u");
		return query.getResultList();
	}

	@Override
	public Utilisateur getUser(Long id) {
		// TODO Auto-generated method stub
		Utilisateur utilisateur = entityManger.find(Utilisateur.class, id);
		return utilisateur;
	}

	@Override
	public Utilisateur Login(String name, String password) {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select u from Utilisateur u WHERE u.username=:x and u.password=:y");
		query.setParameter("x", name);
		query.setParameter("y", password);
		if(query.getResultList().size() == 0) {
			System.out.println("Account does not exist!");
			return null;
		}else {
			System.out.println("Login Success!");
			Utilisateur utilisateur = (Utilisateur) query.getSingleResult();
			System.out.println(utilisateur.getUsername());
			return utilisateur;
		}
		
		
	}

}
