package Entites;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name = "Demande")
public class Demande implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long idDomande;
	private Long ref;
	private String NomProduit;
	private Long quentite;
	private String etatManager;
	private String etatCollecteur;
	@ManyToOne
	private Utilisateur utilisateur;
	public Demande() {
		super();
	}
	public Demande(Long ref, String nomProduit, Long quentite) {
		super();
		this.ref = ref;
		NomProduit = nomProduit;
		this.quentite = quentite;
		this.etatManager = "non approuver";
		this.etatCollecteur = "non recois";
	}
	
	public Demande(Long idDomande, Long ref, String nomProduit, Long quentite, String etatManager) {
		super();
		this.idDomande = idDomande;
		this.ref = ref;
		this.NomProduit = nomProduit;
		this.quentite = quentite;
		this.etatManager = etatManager;
		this.etatCollecteur = "non recois";
	}
	
	public Demande(Long idDomande,Long ref, String nomProduit, Long quentite, String etatManager, String etatCollecteur) {
		super();
		this.idDomande = idDomande;
		this.ref = ref;
		this.NomProduit = nomProduit;
		this.quentite = quentite;
		this.etatManager = etatManager;
		this.etatCollecteur = etatCollecteur;
	}
	public Long getIdDomande() {
		return idDomande;
	}
	public void setIdDomande(Long idDomande) {
		this.idDomande = idDomande;
	}
	public Long getRef() {
		return ref;
	}
	public void setRef(Long ref) {
		this.ref = ref;
	}
	public String getNomProduit() {
		return NomProduit;
	}
	public void setNomProduit(String nomProduit) {
		NomProduit = nomProduit;
	}
	public Long getQuentite() {
		return quentite;
	}
	public void setQuentite(Long quentite) {
		this.quentite = quentite;
	}
	public String getEtatManager() {
		return etatManager;
	}
	public void setEtatManager(String etatManager) {
		this.etatManager = etatManager;
	}
	public String getEtatCollecteur() {
		return etatCollecteur;
	}
	public void setEtatCollecteur(String etatCollecteur) {
		this.etatCollecteur = etatCollecteur;
	}
	
}
