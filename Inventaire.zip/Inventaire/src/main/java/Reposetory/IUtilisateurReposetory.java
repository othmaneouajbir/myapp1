package Reposetory;

import java.util.List;

import Entites.Utilisateur;

public interface IUtilisateurReposetory {
	public void addUser(Utilisateur utilisateur);
	public void updateUser(Utilisateur utilisateur);
	public List<Utilisateur> getUsers();
	public Utilisateur getUser(Long id);
	public Utilisateur Login(String name, String password);

}
