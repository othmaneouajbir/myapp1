package filters;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Entites.Utilisateur;

/**
 * Servlet Filter implementation class AutorizitionFilter
 */
public class AutorizitionFilter implements Filter {

    /**
     * Default constructor. 
     */
	private static String[] pathsv = new String[] {"/Rayon/Produit/Demande"};
	private static String[] pathsm = new String[] {"/DemandeProd"};
	private boolean isRequestVerificateur = false;
	private boolean isRequestMagasinier = false;
	
    public AutorizitionFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		// pass the request along the filter chain
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		String pathInfo = req.getPathInfo();
		String pathServlet = req.getServletPath();
		
		if(pathInfo==null) {
			pathInfo ="";
		}
		if(pathServlet==null) {
			pathServlet ="";
		}
		String chemin = req.getRequestURI().substring(req.getContextPath().length());
		if(chemin.contains("/css") || chemin.contains("/Login")) {
			chain.doFilter(req, resp);
			return;
		}
		
		HttpSession currentsession = req.getSession();
		Utilisateur utilisateur = (Utilisateur) currentsession.getAttribute("user");
		//String action = req.getParameter("action");
		isRequestVerificateur = containesAction(pathsv,pathInfo) && "/Entrepot".equals(pathServlet);
		isRequestMagasinier = containesAction(pathsm,pathInfo) && "/Entrepot".equals(pathServlet);
		Boolean isLogging = currentsession !=null && utilisateur !=null;
		
		//user not connected
		if(!isLogging || currentsession.isNew()) {
			req.getServletContext().getRequestDispatcher("/Login.jsp").forward(req, resp);
			return;
		}
		
		boolean isMagasine = utilisateur.getRole().getTypeRole().equals("magasinier");
		if(isMagasine && isRequestVerificateur) {
			req.getServletContext().getRequestDispatcher("/erreur_403.jsp").forward(req, resp);
			return;
		}
		boolean isVerificateur = utilisateur.getRole().getTypeRole().equals("vérificateur");
		if(isVerificateur && isRequestMagasinier) {
			req.getServletContext().getRequestDispatcher("/erreur_403.jsp").forward(req, resp);
			return;
		}
		
		chain.doFilter(req, resp);
	}
	public static boolean containesAction (String[] actions, String action) {
		return Arrays.stream(actions).anyMatch(action::contains);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
