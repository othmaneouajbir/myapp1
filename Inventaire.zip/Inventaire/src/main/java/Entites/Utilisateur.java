package Entites;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name = "Utilisateur")
public class Utilisateur implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idUser")
	private Long idUser;
	@Column(unique = true)
	private String username;
	private String password;
	@ManyToOne
	private Role role;
	@OneToMany(mappedBy = "utilisateur")
	private List<Demande> demandes;
	public Utilisateur() {
		
	}
	
	
	public Utilisateur(String username, String password) {
		super();
		this.username = username;
		this.password = password;
		this.role = null;
	}

	public Utilisateur(Long idUser, String username, String password, Role role) {
		super();
		this.idUser = idUser;
		this.username = username;
		this.password = password;
		this.role = role;
	}


	public Long getIdUser() {
		return idUser;
	}
	public void setIdUser(Long idUser) {
		this.idUser = idUser;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}


	public List<Demande> getDemandes() {
		return demandes;
	}


	public void setDemandes(List<Demande> demandes) {
		this.demandes = demandes;
	}
	
	
	
}
