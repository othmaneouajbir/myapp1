package Controllors;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entites.Demande;
import Entites.Entrepot;
import Entites.Produit;
import Entites.Rayon;
import Reposetory.DemandeReposetory;
import Reposetory.EntrepotReposetory;
import Reposetory.IDemandeReposetory;
import Reposetory.IEntrepotReposetory;
import Reposetory.IProduitReposetory;
import Reposetory.IRayonReposetory;
import Reposetory.ProduitReposetory;
import Reposetory.RayonReposetory;

/**
 * Servlet implementation class ControllorsEntrepot
 */
public class ControllorsEntrepot extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private IEntrepotReposetory entrepotReposetory;
    private IRayonReposetory rayonReposetory;
    private IProduitReposetory produitReposetory;
    private IDemandeReposetory demandeReposetory; 
    /**
     * @see HttpServlet#HttpServlet()
     */
    @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	entrepotReposetory = new EntrepotReposetory();
    	rayonReposetory = new RayonReposetory();
    	produitReposetory = new ProduitReposetory();
    	demandeReposetory = new DemandeReposetory();
    }
    public ControllorsEntrepot() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getPathInfo();
		
		if(action!=null) {
				if("/Rayon".equalsIgnoreCase(action)) {
					String action1 =request.getParameter("action");
					if(action1==null) {
						Long id = Long.parseLong(request.getParameter("id"));
						request.setAttribute("rayon", rayonReposetory.ListRayonParEntre(id));
						request.setAttribute("idEn", id);
						request.getServletContext().getRequestDispatcher("/rayonList.jsp").forward(request, response);
					}else if(action1.equals("cherche")) {
						Long idCat = Long.parseLong(request.getParameter("categorie"));
						Long idEnt = Long.parseLong(request.getParameter("idEntrepot"));
						request.setAttribute("rayon", rayonReposetory.ListRayonParEntreCat(idEnt,idCat));
						request.getServletContext().getRequestDispatcher("/rayonList.jsp").forward(request, response);
					}		
				}else if("/Rayon/Produit".equalsIgnoreCase(action)) {
					String action2 =request.getParameter("action");
					if(action2==null) {
						Long id2 = Long.parseLong(request.getParameter("id"));
						request.setAttribute("produitt", produitReposetory.ListProduitsParRayon(id2));
						request.setAttribute("idRa", id2);
						System.out.println(produitReposetory.ListProduitsParRayon(id2));
						request.getServletContext().getRequestDispatcher("/produitList.jsp").forward(request, response);
					}else if(action2.equals("Afficher")) {
						String nameCle = request.getParameter("pro");
						Long idRa = Long.parseLong(request.getParameter("idRa"));
						request.setAttribute("produitt", produitReposetory.getproduitByCle(nameCle,idRa));
						request.getServletContext().getRequestDispatcher("/produitList.jsp").forward(request, response);
					}
				}else if("/Rayon/Produit/Demande".equalsIgnoreCase(action)) {
					Long id2 = Long.parseLong(request.getParameter("id"));
					Long id3 = Long.parseLong(request.getParameter("idr"));
					request.setAttribute("produitt", produitReposetory.getProduitRayon(id3, id2));
					request.getServletContext().getRequestDispatcher("/AjouterDemande.jsp").forward(request, response);
				}else if("/DemandeProd".equalsIgnoreCase(action)) {
					Long id = Long.parseLong(request.getParameter("idp"));
					request.setAttribute("produit", produitReposetory.getProduit(id));
					request.getServletContext().getRequestDispatcher("/ajouterQuantite.jsp").forward(request, response);
				}
		}else {
			request.setAttribute("entrepots", entrepotReposetory.getEntropes());
			request.getServletContext().getRequestDispatcher("/Entrepot.jsp").forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action =request.getParameter("action");
		if(action.equals("Saved")) {
			Long ref = Long.parseLong(request.getParameter("ref"));
			Long qprod = Long.parseLong(request.getParameter("qprod"));
			String nom = request.getParameter("nprod");
			Demande demande = new Demande(ref, nom, qprod);
			demandeReposetory.addDemande(demande);	
			response.sendRedirect("/Inventaire/Entrepot");
		}else if(action.equals("ajou")) {
			try {
				String nomp = request.getParameter("nomP");
				Double prix = Double.parseDouble(request.getParameter("prix"));
				Long quantite = Long.parseLong(request.getParameter("qt1"));
				Long quantiteA = Long.parseLong(request.getParameter("qt"));
				Long idProd =Long.parseLong(request.getParameter("idProduit"));
				Long idRayon =Long.parseLong(request.getParameter("idRayon"));
				Date Date= new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("date"));
				Rayon rayon = rayonReposetory.getRayon(idRayon);
				if(quantiteA>quantite) {
					String mesg = "la quantiter demander et superieur de celle de nous stock";
					System.out.println(mesg);
					response.sendRedirect("/Inventaire/Entrepot");
				}else {
					Long qntite = quantite - quantiteA;
					if(qntite==0) {
						String etat = "nnDispo";
						Produit produit = new Produit(idProd, nomp, prix, qntite, Date, etat, rayon);
						produitReposetory.updateProduit(produit);
					}else {
						String etat = "Dispo";
						Produit produit = new Produit(idProd, nomp, prix, qntite, Date, etat, rayon);
						produitReposetory.updateProduit(produit);
					}
					double prixT = prix * quantiteA;
					request.setAttribute("qt", quantiteA);
					request.setAttribute("prix", prixT);
					request.setAttribute("nom", nomp);
					request.getServletContext().getRequestDispatcher("/FactureMag.jsp").forward(request, response);
				}
				
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		
		
	}

}
