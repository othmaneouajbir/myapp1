package Entites;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Entrepot")
public class Entrepot implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long idEntrepo;
	private String name;
	private String address;
	@OneToMany(mappedBy = "entrepot")
	private List<Rayon> rayons = new ArrayList<Rayon>();

	public Entrepot() {
		super();
	}
	

	public Entrepot(Long idEntrepo, String name, String address) {
		super();
		this.idEntrepo = idEntrepo;
		this.name = name;
		this.address = address;
	}


	public Entrepot(String name, String address) {
		super();
		this.name = name;
		this.address = address;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getIdEntrepo() {
		return idEntrepo;
	}

	public void setIdEntrepo(Long idEntrepo) {
		this.idEntrepo = idEntrepo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	

	public List<Rayon> getRayons() {
		return rayons;
	}

	public void setRayons(List<Rayon> rayons) {
		this.rayons = rayons;
	}

}
