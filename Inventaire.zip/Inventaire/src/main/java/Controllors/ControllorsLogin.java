package Controllors;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entites.Utilisateur;
import Reposetory.IUtilisateurReposetory;
import Reposetory.UtilisateurReposetory;

/**
 * Servlet implementation class ControllorsLogin
 */
public class ControllorsLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private IUtilisateurReposetory utilisateurReposetory;
    @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	utilisateurReposetory = new UtilisateurReposetory();
    }
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllorsLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Utilisateur utilisateur = (Utilisateur) request.getSession().getAttribute("user");
		if(utilisateur!=null) {
			request.getServletContext().getRequestDispatcher("/CreeCompte.jsp").forward(request, response);
		}else {
			request.getServletContext().getRequestDispatcher("/Login.jsp").forward(request, response);
		}
		
		/*String path = request.getPathInfo();
		if(path==null) {
			request.getServletContext().getRequestDispatcher("/Login.jsp").forward(request, response);
		}else {
			if("/CreeCompte".equalsIgnoreCase(path)) {
				request.getServletContext().getRequestDispatcher("/CreeCompte.jsp").forward(request, response);
			}
		}*/
		
		//request.getServletContext().getRequestDispatcher("/Rayon.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action =request.getParameter("action");
		if(action.equals("Login")) {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			Utilisateur utilisateur = utilisateurReposetory.Login(username, password);
			if(utilisateur!=null) {
				request.getSession().setAttribute("user", utilisateur);
				if(utilisateur.getRole().getTypeRole().equals("admin")) {
					response.sendRedirect("/Inventaire/Admin");
				}else if(utilisateur.getRole().getTypeRole().equals("manger")) {
					response.sendRedirect("/Inventaire/EntrepoteManger");
				}else if(utilisateur.getRole().getTypeRole().equals("vérificateur")) {
					response.sendRedirect("/Inventaire/Entrepot");
				}else if(utilisateur.getRole().getTypeRole().equals("magasinier")) {
					response.sendRedirect("/Inventaire/Entrepot");
				}else if(utilisateur.getRole().getTypeRole().equals("collecteur")) {
					response.sendRedirect("/Inventaire/Collecteur");
				}
				
			}else {
				response.sendRedirect("/Inventaire/Login");
			}
		}else if(action.equals("Creer")) {
			String username = request.getParameter("nom");
			String password = request.getParameter("pass");
			String passConf = request.getParameter("conpass");
			if(password.equals(passConf)) {
				Utilisateur utilisateur = new Utilisateur(username, password);
				utilisateurReposetory.addUser(utilisateur);
				response.sendRedirect("/Inventaire/Login");
			}else {
				response.sendRedirect("/Inventaire/Login/CreeCompte");
			}
		}
		
		
	}

}
