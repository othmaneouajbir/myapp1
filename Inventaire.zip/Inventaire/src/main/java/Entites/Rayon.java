package Entites;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Rayon")
public class Rayon implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long idRayon;
	private String name;
	private Long nombre_max;
	@OneToMany(mappedBy = "rayon")
	private List<Produit> produits = new ArrayList<Produit>();
	@ManyToOne
	private Entrepot entrepot;
	@ManyToOne
	private Categorie categorie;

	public Rayon() {
	}

	public Rayon(Long idRayon, String name, Long nombre_max, Entrepot entrepot, Categorie categorie) {
		super();
		this.idRayon = idRayon;
		this.name = name;
		this.nombre_max = nombre_max;
		this.entrepot = entrepot;
		this.categorie = categorie;
	}

	public Rayon(String name, Long nombre_max, Entrepot entrepot, Categorie categorie) {
		super();
		this.name = name;
		this.nombre_max = nombre_max;
		this.entrepot = entrepot;
		this.categorie = categorie;
	}

	public Rayon(Long idRayon, String name, Long nombre_max, Entrepot entrepot) {
		super();
		this.idRayon = idRayon;
		this.name = name;
		this.nombre_max = nombre_max;
		this.entrepot = entrepot;
	}

	public Rayon(String name, Long nombre_max, Entrepot entrepot) {
		super();
		this.name = name;
		this.nombre_max = nombre_max;
		this.entrepot = entrepot;
	}

	public Rayon(Long idRayon, String name, Long nombre_max) {
		this.idRayon = idRayon;
		this.name = name;
		this.nombre_max = nombre_max;
	}

	public Rayon(String name, Long nombre_max) {
		super();
		this.name = name;
		this.nombre_max = nombre_max;
	}

	public Categorie getCategorie() {
		return categorie;
	}

	public void setCategorie(Categorie categorie) {
		this.categorie = categorie;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getIdRayon() {
		return idRayon;
	}

	public void setIdRayon(Long idRayon) {
		this.idRayon = idRayon;
	}

	public Long getNombre_max() {
		return nombre_max;
	}

	public Entrepot getEntrepot() {
		return entrepot;
	}

	@Override
	public String toString() {
		return "Rayon [idRayon=" + idRayon + ", name=" + name + ", nombre_max=" + nombre_max + ", produits=" + produits
				+ ", entrepot=" + entrepot + ", categorie=" + categorie + "]";
	}

	public void setEntrepot(Entrepot entrepot) {
		this.entrepot = entrepot;
	}

	public void setNombre_max(Long nombre_max) {
		this.nombre_max = nombre_max;
	}

	public List<Produit> getProduits() {
		return produits;
	}

	public void setProduits(List<Produit> produits) {
		this.produits = produits;
	}

}
