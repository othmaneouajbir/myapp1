package Controllors;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entites.Categorie;
import Reposetory.CategorieReposetory;
import Reposetory.ICategorieReposetory;

/**
 * Servlet implementation class ControllorsCategorie
 */
public class ControllorsCategorie extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ICategorieReposetory categorieReposetory;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		categorieReposetory = new CategorieReposetory();
	}
    public ControllorsCategorie() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getPathInfo();
		if(action!=null) {
			Long id = Long.parseLong(request.getParameter("id"));
			if("/edite".equalsIgnoreCase(action)) {
				Categorie categorie = categorieReposetory.getCategorie(id);
				request.setAttribute("categorie", categorie);
				request.setAttribute("categories", categorieReposetory.getCategories());
			}else if("/delete".equalsIgnoreCase(action)) {
				categorieReposetory.deleteCategorie(id);
				request.setAttribute("categories", categorieReposetory.getCategories());
			}
		}else {
			request.setAttribute("categories", categorieReposetory.getCategories());
		}
		request.setAttribute("categories", categorieReposetory.getCategories());
		request.getServletContext().getRequestDispatcher("/Categorie.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action =request.getParameter("action");
		String name = request.getParameter("name");
		if(action.equals("Save")) {
			Categorie categorie = new Categorie(name);
			categorieReposetory.addCategorie(categorie);
		}else if(action.equals("Edite")) {
			Long id = Long.parseLong(request.getParameter("idCat"));
			Categorie categorie = new Categorie(id, name);
			categorieReposetory.updateCategorie(categorie);
		}
		response.sendRedirect("/Inventaire/Categorie");
	}

}
