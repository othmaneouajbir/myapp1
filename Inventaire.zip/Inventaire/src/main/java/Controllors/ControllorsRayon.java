package Controllors;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entites.Categorie;
import Entites.Entrepot;
import Entites.Rayon;
import Reposetory.CategorieReposetory;
import Reposetory.EntrepotReposetory;
import Reposetory.ICategorieReposetory;
import Reposetory.IEntrepotReposetory;
import Reposetory.IProduitReposetory;
import Reposetory.IRayonReposetory;
import Reposetory.ProduitReposetory;
import Reposetory.RayonReposetory;

/**
 * Servlet implementation class ControllorsRayon
 */
public class ControllorsRayon extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private IRayonReposetory rayonReposetory;
    private IEntrepotReposetory entrepotReposetory;
    private ICategorieReposetory categorieReposetory;

    /**
     * @see HttpServlet#HttpServlet()
     */
    @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	rayonReposetory = new RayonReposetory();
    	entrepotReposetory = new EntrepotReposetory();
    	categorieReposetory = new CategorieReposetory();
    	
    }
    public ControllorsRayon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getPathInfo();
		if(action!=null) {
			Long id = Long.parseLong(request.getParameter("id"));
			if("/edite".equalsIgnoreCase(action)) {
				Rayon rayon = rayonReposetory.getRayon(id);
				request.setAttribute("rayon", rayon);
				request.setAttribute("rayons", rayonReposetory.getRayons());
			}else if("/delete".equalsIgnoreCase(action)) {
				rayonReposetory.deleteRayon(id);
				request.setAttribute("rayons", rayonReposetory.getRayons());
			}
		}else {
			request.setAttribute("rayons", rayonReposetory.getRayons());
		}
		request.setAttribute("categories", categorieReposetory.getCategories());
		request.setAttribute("entropts", entrepotReposetory.getEntropes());
		request.setAttribute("rayons", rayonReposetory.getRayons());
		request.getServletContext().getRequestDispatcher("/Rayon.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getParameter("action");
		String name = request.getParameter("name");
		Long nbr = Long.parseLong(request.getParameter("nbr"));
		if(action.equals("Save")) {
			Long id1 = Long.parseLong(request.getParameter("categorie"));
			Long id2 = Long.parseLong(request.getParameter("entrepot"));
			Categorie categorie = categorieReposetory.getCategorie(id1);
			Entrepot entrepot = entrepotReposetory.getEntrepot(id2);	
			Rayon rayon = new Rayon(name, nbr, entrepot, categorie);
			rayonReposetory.addRayon(rayon);
		}else if(action.equals("Edite")) {
			Long id1 = Long.parseLong(request.getParameter("idRayon"));
			Long id2 = Long.parseLong(request.getParameter("categorie"));
			Long id3 = Long.parseLong(request.getParameter("entrepot"));
			Categorie categorie = categorieReposetory.getCategorie(id2);
			Entrepot entrepot = entrepotReposetory.getEntrepot(id3);
			Rayon rayon = new Rayon(id1, name, nbr, entrepot, categorie);
			rayonReposetory.updateRayon(rayon);
		}
		response.sendRedirect("/Inventaire/Rayon");
	}

}
