package Reposetory;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import Entites.Rayon;

public class RayonReposetory implements IRayonReposetory{
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("inva");
	private EntityManager entityManger = entityManagerFactory.createEntityManager();
	@Override
	public void addRayon(Rayon rayon) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			entityManger.persist(rayon);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
	}

	@Override
	public void deleteRayon(Long idRayon) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			Rayon rayon = entityManger.find(Rayon.class, idRayon);
			entityManger.remove(rayon);
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void updateRayon(Rayon rayon) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			entityManger.merge(rayon);
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Rayon getRayon(Long idRayon) {
		// TODO Auto-generated method stub
		Rayon rayon = entityManger.find(Rayon.class, idRayon);
		return rayon;
	}

	@Override
	public List<Rayon> getRayons() {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select r from Rayon r");
		return query.getResultList();
	}

	@Override
	public List<Rayon> ListRayonParEntre(Long id) {
		// TODO Auto-generated method stub 
		Query query = entityManger.createQuery("select r from Rayon r JOIN r.entrepot e WHERE e.idEntrepo= :id");
		//Query query = entityManger.createQuery("select r from Rayon r WHERE r.getEntrepot().getIdEntrepo()= :id");
		//Query query2 = entityManger.createNativeQuery("SELECT * FROM rayon where entrepot_id = :id");
		query.setParameter("id", id);
		System.out.println(query.getResultList().toString());
		return query.getResultList();
	}

	@Override
	public List<Rayon> ListRayonParEntreCat(Long idEnt, Long idCat) {
		// TODO Auto-generated method stub
		//Query query = entityManger.createQuery("select r from Rayon r inner JOIN Categorie c inner JOIN Entrepot e WHERE c.idCat= :id1 and e.idEntrepo= :id");
		Query query = entityManger.createQuery("select r from Rayon r  JOIN r.categorie c JOIN r.entrepot e WHERE c.idCat= :id1 and e.idEntrepo= :id");
		query.setParameter("id1", idCat);	
		query.setParameter("id", idEnt);
		
		return query.getResultList();
	}

	@Override
	public List<Rayon> ListRayonParCat(Long idCat) {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select r from Rayon r JOIN r.categorie c WHERE c.idCat= :id1");
		query.setParameter("id1", idCat);
		return query.getResultList();
	}

	@Override
	public List<Rayon> getRayonCat() {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select DISTINCT c from Rayon r JOIN r.categorie c");
		return query.getResultList();
	}

}
