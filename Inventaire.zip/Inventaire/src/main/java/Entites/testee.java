package Entites;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class testee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("inva");
	}

}
