package Reposetory;

import java.util.List;

import Entites.Demande;

public interface IDemandeReposetory {
	public void addDemande(Demande demande);
	public void deleteDemande(Long id);
	public void updateDemande(Demande demande);
	public List<Demande> getDemandes();
	public Demande getDemande(Long id);
	public List<Demande> getDemandeByEtat();
}
