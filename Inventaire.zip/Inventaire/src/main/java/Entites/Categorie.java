package Entites;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Categorie")
public class Categorie {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long idCat;
	private String name;
	@OneToMany(mappedBy = "categorie")
	private List<Rayon> rayons = new ArrayList<Rayon>();

	public Categorie() {
	}

	public Categorie(String name) {
		super();
		this.name = name;
	}

	public Categorie(Long idCat, String name) {
		super();
		this.idCat = idCat;
		this.name = name;
	}

	public Long getIdCat() {
		return idCat;
	}

	public void setIdCat(Long idCat) {
		this.idCat = idCat;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Rayon> getRayons() {
		return rayons;
	}

	public void setRayons(List<Rayon> rayons) {
		this.rayons = rayons;
	}

}
