package Reposetory;

import java.util.List;

import Entites.Role;

public interface IRoleReposetory {
	public void addRole(Role role);
	public List<Role> getRoles();
	public void deleteRole(Long id);
	public Role getRole(Long id);
}
