package Entites;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "PRODUITS")
public class Produit implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long idProduit;
	@Column(unique = true)
	private Long refProduit;
	private String nameProduit;
	private Double prix;
	private Long quantity;
	@Temporal(TemporalType.DATE)
	private Date expirationDate;
	private String stateOfProduit;
	@ManyToOne
	private Rayon rayon;

	public Produit(Long idProduit, String nameProduit, Double prix, Long quantity) {
		super();
		this.idProduit = idProduit;
		this.refProduit = (long) (Math.random()*100);
		this.nameProduit = nameProduit;
		this.prix = prix;
		this.quantity = quantity;
	}

	public Produit() {

	}
	



	public Produit(String nameProduit, Double prix, Long quantity,Date expirationDate,String stateOfProduit, Rayon rayon) {
		super();
		this.nameProduit = nameProduit;
		this.refProduit = (long) (Math.random()*1000);
		this.prix = prix;
		this.quantity = quantity;
		this.rayon = rayon;
		this.expirationDate = expirationDate;
		this.stateOfProduit = stateOfProduit;
	}

	public Produit(String nameProduit, Double prix, Long quantity) {
		super();
		this.refProduit = (long) (Math.random()*1000);
		this.nameProduit = nameProduit;
		this.prix = prix;
		this.quantity = quantity;
	}

	public Produit(Long idProduit, String nameProduit, Double prix, Long quantity,Date expirationDate,String stateOfProduit, Rayon rayon) {
		super();
		this.idProduit = idProduit;
		this.refProduit = (long) (Math.random()*1000);
		this.nameProduit = nameProduit;
		this.prix = prix;
		this.quantity = quantity;
		this.rayon = rayon;
		this.expirationDate = expirationDate;
		this.stateOfProduit = stateOfProduit;
	}

	public String getStateOfProduit() {
		return stateOfProduit;
	}

	public void setStateOfProduit(String stateOfProduit) {
		this.stateOfProduit = stateOfProduit;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Long getRefProduit() {
		return refProduit;
	}

	public void setRefProduit(Long refProduit) {
		this.refProduit = refProduit;
	}

	public String getNameProduit() {
		return nameProduit;
	}

	public void setNameProduit(String nameProduit) {
		this.nameProduit = nameProduit;
	}

	public Double getPrix() {
		return prix;
	}

	public void setPrix(Double prix) {
		this.prix = prix;
	}

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	public Rayon getRayon() {
		return rayon;
	}

	public void setRayon(Rayon rayon) {
		this.rayon = rayon;
	}

	public Long getIdProduit() {
		return idProduit;
	}

	public void setIdProduit(Long idProduit) {
		this.idProduit = idProduit;
	}

}
