package Reposetory;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import Entites.Role;

public class RoleReposetory implements IRoleReposetory{
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("inva");
	private EntityManager entityManger = entityManagerFactory.createEntityManager();
	@Override
	public void addRole(Role role) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			entityManger.persist(role);
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			transaction.rollback();
			e.printStackTrace();
		}
	}

	@Override
	public List<Role> getRoles() {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("select r from Role r");
		return query.getResultList();
	}

	@Override
	public void deleteRole(Long id) {
		// TODO Auto-generated method stub
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		try {
			Role role = entityManger.find(Role.class, id);
			entityManger.remove(role);
			transaction.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}

	@Override
	public Role getRole(Long id) {
		// TODO Auto-generated method stub
		Role role = entityManger.find(Role.class, id);
		return role;
	}

}
