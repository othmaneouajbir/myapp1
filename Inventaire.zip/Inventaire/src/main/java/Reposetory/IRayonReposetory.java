package Reposetory;

import java.util.List;

import Entites.Rayon;

public interface IRayonReposetory {
	public void addRayon(Rayon rayon);
	public void deleteRayon(Long idRayon);
	public void updateRayon(Rayon rayon);
	public Rayon getRayon(Long idRayon);
	public List<Rayon> getRayons();
	public List<Rayon> getRayonCat();
	public List<Rayon> ListRayonParEntre(Long id);
	public List<Rayon> ListRayonParEntreCat(Long idEnt, Long idCat);
	public List<Rayon> ListRayonParCat(Long idCat);
}
