package Entites;

public class testTT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Long x = (long) Math.random()*10;
		System.out.println(x);
	}

}
