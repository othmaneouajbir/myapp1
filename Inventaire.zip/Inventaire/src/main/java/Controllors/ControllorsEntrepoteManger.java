	package Controllors;

import java.io.IOException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entites.Categorie;
import Entites.Demande;
import Entites.Entrepot;
import Entites.Produit;
import Entites.Rayon;
import Reposetory.CategorieReposetory;
import Reposetory.DemandeReposetory;
import Reposetory.EntrepotReposetory;
import Reposetory.ICategorieReposetory;
import Reposetory.IDemandeReposetory;
import Reposetory.IEntrepotReposetory;
import Reposetory.IProduitReposetory;
import Reposetory.IRayonReposetory;
import Reposetory.ProduitReposetory;
import Reposetory.RayonReposetory;

/**
 * Servlet implementation class ControllorsEntrepoteManger
 */
public class ControllorsEntrepoteManger extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private IEntrepotReposetory entrepotReposetory;
	private IRayonReposetory rayonReposetory;
	private ICategorieReposetory categorieReposetory; 
	private IProduitReposetory produitReposetory;
	private IDemandeReposetory demandeReposetory; 
    /**
     * @see HttpServlet#HttpServlet()
     */
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		entrepotReposetory = new EntrepotReposetory();
		categorieReposetory = new CategorieReposetory();
		rayonReposetory = new RayonReposetory();
		produitReposetory = new ProduitReposetory();
		demandeReposetory = new DemandeReposetory();
	}
    public ControllorsEntrepoteManger() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getPathInfo();
		String action2 =request.getParameter("action");
		if(action!=null) {
			if("/Rayon".equalsIgnoreCase(action)) {
				if(action2==null) {
					request.setAttribute("entrepots", entrepotReposetory.getEntropes());
					request.setAttribute("categories", categorieReposetory.getCategories());
					request.setAttribute("rayons", rayonReposetory.getRayons());
					request.getServletContext().getRequestDispatcher("/Rayon.jsp").forward(request, response);
				}else if(action2.equals("chercheR")){
					Long id = Long.parseLong(request.getParameter("categorie"));
					request.setAttribute("rayons", rayonReposetory.ListRayonParCat(id));
					request.getServletContext().getRequestDispatcher("/Rayon.jsp").forward(request, response);
				}else if(action2.equals("ajouterR")) {
					request.setAttribute("entrepots", entrepotReposetory.getEntropes());
					request.setAttribute("categories", categorieReposetory.getCategories());
					request.getServletContext().getRequestDispatcher("/AjoutRayon.jsp").forward(request, response);
				}
			}else if("/Rayon/editeR".equalsIgnoreCase(action)) {
				request.setAttribute("entrepots", entrepotReposetory.getEntropes());
				request.setAttribute("categories", categorieReposetory.getCategories());
				Long id = Long.parseLong(request.getParameter("id"));
				Rayon rayon = rayonReposetory.getRayon(id);
				request.setAttribute("rayon", rayon);
				request.getServletContext().getRequestDispatcher("/EditeRayon.jsp").forward(request, response);
			}else if("/Rayon/deleteR".equalsIgnoreCase(action)) {
				Long id = Long.parseLong(request.getParameter("id"));
				rayonReposetory.deleteRayon(id);
				response.sendRedirect("/Inventaire/EntrepoteManger/Rayon");
			}else if("/Produit".equalsIgnoreCase(action)) {
				if(action2==null) {
					request.setAttribute("rayons", rayonReposetory.getRayons());
					request.setAttribute("produits", produitReposetory.getProduits());
					request.getServletContext().getRequestDispatcher("/Produit.jsp").forward(request, response);
				}else if(action2.equals("chercheP")) {
					String name = request.getParameter("mocleP");
					request.setAttribute("produits", produitReposetory.getproduitByName(name));
					request.getServletContext().getRequestDispatcher("/Produit.jsp").forward(request, response);
				}else if(action2.equals("ajouterP")) {
					request.setAttribute("rayons", rayonReposetory.getRayons());
					request.getServletContext().getRequestDispatcher("/AjoutProduit.jsp").forward(request, response);
				}
			}else if("/Produit/editeP".equalsIgnoreCase(action)) {
				request.setAttribute("rayons", rayonReposetory.getRayons());
				Long id = Long.parseLong(request.getParameter("id"));
				Produit produit = produitReposetory.getProduit(id);
				request.setAttribute("produit", produit);
				request.getServletContext().getRequestDispatcher("/EditeProduit.jsp").forward(request, response);
			}else if("/Produit/deleteP".equalsIgnoreCase(action)) {
				Long id = Long.parseLong(request.getParameter("id"));
				produitReposetory.deleteProduit(id);
				response.sendRedirect("/Inventaire/EntrepoteManger/Produit");
			}else if("/Categorie".equalsIgnoreCase(action)) {
				if(action2==null) {
					request.setAttribute("categories", categorieReposetory.getCategories());
					request.getServletContext().getRequestDispatcher("/Categorie.jsp").forward(request, response);
				}else if(action2.equals("chercheC")) {
					String name = request.getParameter("mocleC");
					request.setAttribute("categories", categorieReposetory.getCategoriesByCle(name));
					request.getServletContext().getRequestDispatcher("/Categorie.jsp").forward(request, response);
				}else if(action2.equals("ajouterC")) {
					request.getServletContext().getRequestDispatcher("/AjoutCat.jsp").forward(request, response);
				}
			}else if("/Categorie/editeC".equalsIgnoreCase(action)) {
				Long id = Long.parseLong(request.getParameter("id"));
				Categorie categorie = categorieReposetory.getCategorie(id);
				request.setAttribute("categorie", categorie);
				request.getServletContext().getRequestDispatcher("/EditeCat.jsp").forward(request, response);
			}else if("/Categorie/deleteC".equalsIgnoreCase(action)) {
				Long id = Long.parseLong(request.getParameter("id"));
				categorieReposetory.deleteCategorie(id);
				response.sendRedirect("/Inventaire/EntrepoteManger/Categorie");
			}else if("/Demande".equalsIgnoreCase(action)) {
				request.setAttribute("demandes", demandeReposetory.getDemandes());
				request.getServletContext().getRequestDispatcher("/ListDemande.jsp").forward(request, response);
			}else if("/Demande/editeEtat".equalsIgnoreCase(action)) {
				Long id = Long.parseLong(request.getParameter("id"));
				Demande demande = demandeReposetory.getDemande(id);
				request.setAttribute("demande", demande);
				request.getServletContext().getRequestDispatcher("/editeEtatM.jsp").forward(request, response);
			}
			
			else if("/delete".equalsIgnoreCase(action)) {
				Long id = Long.parseLong(request.getParameter("id"));
				entrepotReposetory.deleteEntrepot(id);
				response.sendRedirect("/Inventaire/EntrepoteManger");
			}else if("/edite".equalsIgnoreCase(action)) {
				Long id = Long.parseLong(request.getParameter("id"));
				Entrepot entrepot = entrepotReposetory.getEntrepot(id);
				request.setAttribute("entrepot", entrepot);
				request.getServletContext().getRequestDispatcher("/EditeEntr.jsp").forward(request, response);
			}else if("/Entrepot".equalsIgnoreCase(action)) {
				response.sendRedirect("/Inventaire/EntrepoteManger");
			}
		}else if(action2==null){
			request.setAttribute("entrepots", entrepotReposetory.getEntropes());
			request.setAttribute("rayons", rayonReposetory.getRayons());
			request.setAttribute("produits", produitReposetory.getProduits());
			request.setAttribute("categories", categorieReposetory.getCategories());
			request.getServletContext().getRequestDispatcher("/Entrepote.jsp").forward(request, response);
		}else if(action2.equals("cherche")) {
			String name = request.getParameter("mocle");
			request.setAttribute("entrepots", entrepotReposetory.getEntrepesByCle(name));
			request.getServletContext().getRequestDispatcher("/Entrepote.jsp").forward(request, response);
		}else if(action2.equals("ajouter")) {
			request.getServletContext().getRequestDispatcher("/AjoutEntr.jsp").forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action =request.getParameter("action");
		if(action.equals("Save")) {
			String name = request.getParameter("name");
			String adresse = request.getParameter("add");
			Entrepot entrepot = new Entrepot(name, adresse);
			entrepotReposetory.addEntrepot(entrepot);
			response.sendRedirect("/Inventaire/EntrepoteManger");
		} else if(action.equals("Edite")) {
			String name = request.getParameter("name");
			String adresse = request.getParameter("add");
			Long id = Long.parseLong(request.getParameter("idEntrepot"));
			Entrepot entrepot = new Entrepot(id, name, adresse);
			entrepotReposetory.updateEntrepot(entrepot);
			response.sendRedirect("/Inventaire/EntrepoteManger");
		}else if(action.equals("Saver")) {
			String nomr = request.getParameter("nomR");
			Long nbrR = Long.parseLong(request.getParameter("nbrR"));
			Long idc = Long.parseLong(request.getParameter("categorie"));
			Long ide = Long.parseLong(request.getParameter("entrepot"));
			Categorie categorie = categorieReposetory.getCategorie(idc);
			Entrepot entrepot = entrepotReposetory.getEntrepot(ide);
			Rayon rayon = new Rayon(nomr, nbrR, entrepot, categorie);
			rayonReposetory.addRayon(rayon);
			response.sendRedirect("/Inventaire/EntrepoteManger/Rayon");
		}else if(action.equals("EditeR")) {
			String nomr = request.getParameter("nomR");
			Long nbrR = Long.parseLong(request.getParameter("nbrR"));
			Long id1 = Long.parseLong(request.getParameter("idRayon"));
			Long id2 = Long.parseLong(request.getParameter("categorie"));
			Long id3 = Long.parseLong(request.getParameter("entrepot"));
			Categorie categorie = categorieReposetory.getCategorie(id2);
			Entrepot entrepot = entrepotReposetory.getEntrepot(id3);
			Rayon rayon = new Rayon(id1, nomr, nbrR, entrepot, categorie);
			rayonReposetory.updateRayon(rayon);
			response.sendRedirect("/Inventaire/EntrepoteManger/Rayon");
		}else if(action.equals("Savep")) {
			try {
				String nameP = request.getParameter("nomP");
				Double prix = Double.parseDouble(request.getParameter("prix"));
				Long quantite = Long.parseLong(request.getParameter("qt"));
				Date Date= new SimpleDateFormat("dd-MM-yyyy").parse(request.getParameter("date"));
				Long id = Long.parseLong(request.getParameter("rayon"));
				Rayon rayon = rayonReposetory.getRayon(id);

				if(quantite==0) {
					String etat = "nnDispo";
					Produit produit = new Produit(nameP, prix, quantite, Date, etat, rayon);
					produitReposetory.addProduit(produit);
				}else {
					String etat = "Dispo";
					Produit produit = new Produit(nameP, prix, quantite, Date, etat, rayon);
					produitReposetory.addProduit(produit);

				}
				
				
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.sendRedirect("/Inventaire/EntrepoteManger/Produit");
		}else if(action.equals("Editep")) {
			try {
				String nameP = request.getParameter("nomP");
				Double prix = Double.parseDouble(request.getParameter("prix"));
				Long quantite = Long.parseLong(request.getParameter("qt"));
				
				Long id1 =Long.parseLong(request.getParameter("idProduit"));
				Long id = Long.parseLong(request.getParameter("rayon"));
				Rayon rayon = rayonReposetory.getRayon(id);
				Date Date= new SimpleDateFormat("dd-MM-yyyy").parse(request.getParameter("date"));
				

				if(quantite==0) {
					String etat = "nnDispo";
					Produit produit = new Produit(id1, nameP, prix, quantite, Date, etat, rayon);
					produitReposetory.updateProduit(produit);
				}else {
					String etat = "Dispo";
					Produit produit = new Produit(id1, nameP, prix, quantite, Date, etat, rayon);
					produitReposetory.updateProduit(produit);

				}
				
				
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.sendRedirect("/Inventaire/EntrepoteManger/Produit");
		}else if(action.equals("Savec")) {
			String name = request.getParameter("nomC");
			Categorie categorie = new Categorie(name);
			categorieReposetory.addCategorie(categorie);
			response.sendRedirect("/Inventaire/EntrepoteManger/Categorie");
		}else if(action.equals("Editec")) {
			String name = request.getParameter("nomC");
			Long id = Long.parseLong(request.getParameter("idCat"));
			Categorie categorie = new Categorie(id, name);
			categorieReposetory.updateCategorie(categorie);
			response.sendRedirect("/Inventaire/EntrepoteManger/Categorie");
		}else if(action.equals("EditeETAT")) {
			String nomp = request.getParameter("nomp");
			Long idD = Long.parseLong(request.getParameter("idD"));
			Long ref = Long.parseLong(request.getParameter("ref"));
			Long qprod = Long.parseLong(request.getParameter("qprod"));
			String etat = request.getParameter("etatM");
			Demande demande = new Demande(idD, ref, nomp, qprod, etat);
			demandeReposetory.updateDemande(demande);
			response.sendRedirect("/Inventaire/EntrepoteManger/Demande");
		}
		
	}

}
